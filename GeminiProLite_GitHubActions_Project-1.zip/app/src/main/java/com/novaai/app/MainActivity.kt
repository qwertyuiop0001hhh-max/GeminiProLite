package com.geminiprolite.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class Message(val text:String, val user:Boolean)

class MainActivity: ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GeminiProLiteApp() }
    }
}

@Composable
fun GeminiProLiteApp() {
    var input by remember { mutableStateOf("") }
    var messages by remember { mutableStateOf(listOf<Message>()) }
    var tab by remember { mutableStateOf("Chat") }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Color(0xFF0B0B10),
        surface = Color(0xFF15151D),
        primary = Color(0xFF9B8CFF)
    )) {
        Surface(Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize().padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("✦", fontSize=30.sp, color=Color(0xFFB7AAFF))
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("Gemini Pro Lite", fontSize=22.sp, fontWeight=FontWeight.Bold)
                        Text("Ваш универсальный AI", color=Color.Gray, fontSize=12.sp)
                    }
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick={}) { Text("•••") }
                }

                Spacer(Modifier.height(12.dp))

                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    listOf("Chat","Видео","Изображения").forEach {
                        FilterChip(selected=tab==it, onClick={tab=it}, label={Text(it)})
                    }
                }

                Spacer(Modifier.height(12.dp))

                if (tab == "Chat") {
                    if (messages.isEmpty()) {
                        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment=Alignment.Center) {
                            Column(horizontalAlignment=Alignment.CenterHorizontally) {
                                Text("Чем могу помочь?", fontSize=28.sp, fontWeight=FontWeight.Bold)
                                Spacer(Modifier.height(8.dp))
                                Text("Напишите вопрос или задачу", color=Color.Gray)
                            }
                        }
                    } else {
                        LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement=Arrangement.spacedBy(10.dp)) {
                            items(messages) { m ->
                                Row(Modifier.fillMaxWidth(), horizontalArrangement=if(m.user) Arrangement.End else Arrangement.Start) {
                                    Surface(shape=RoundedCornerShape(18.dp), color=if(m.user) Color(0xFF292443) else Color(0xFF17171F)) {
                                        Text(m.text, Modifier.padding(14.dp), fontSize=15.sp)
                                    }
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        OutlinedTextField(
                            value=input, onValueChange={input=it}, modifier=Modifier.weight(1f),
                            placeholder={Text("Спросите Gemini Pro Lite...")}, shape=RoundedCornerShape(22.dp),
                            maxLines=4
                        )
                        Spacer(Modifier.width(8.dp))
                        Button(onClick={
                            if(input.isNotBlank()){
                                val q=input
                                messages=messages + Message(q,true) + Message("Демо-ответ Gemini Pro Lite. Подключите AI-бэкенд, чтобы получать реальные ответы, изображения и видео.",false)
                                input=""
                            }
                        }, shape=RoundedCornerShape(20.dp)) { Text("➤") }
                    }
                } else if (tab == "Видео") {
                    VideoGeneratorScreen()
                } else {
                    Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment=Alignment.Center) {
                        Column(horizontalAlignment=Alignment.CenterHorizontally) {
                            Text("✦", fontSize=48.sp)
                            Spacer(Modifier.height(12.dp))
                            Text("Генерация изображений", fontSize=24.sp, fontWeight=FontWeight.Bold)
                            Spacer(Modifier.height(8.dp))
                            Text("Интерфейс готов. Подключается через AI API.", color=Color.Gray)
                            Spacer(Modifier.height(20.dp))
                            Button(onClick={}) { Text("Создать") }
                        }
                    }
                }
            }
        }
    }
}
