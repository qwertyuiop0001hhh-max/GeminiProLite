# Сборка APK через GitHub Actions

1. Создайте GitHub-репозиторий.
2. Загрузите в него все файлы этого проекта.
3. Откройте вкладку **Actions**.
4. Выберите **Build Android APK**.
5. Нажмите **Run workflow**.
6. После завершения откройте готовый workflow и скачайте artifact **Gemini-Pro-Lite-debug**.
7. Внутри будет файл `.apk`, который можно установить на Android.

Workflow также запускается автоматически при push в `main` или `master`.

Важно: это debug APK для тестирования. Для публикации в Google Play нужен release build с подписью.
